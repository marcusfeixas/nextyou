
import React from 'react';
import { useAuth } from '../auth/useAuth';
import Card from '../../components/common/Card';
import { PointsIcon, BadgeIcon, ShareIcon, CopyIcon } from '../../components/icons/FluentIcons';
import { toast } from 'react-toastify';
import Button from '../../components/common/Button';

const ProfilePage: React.FC = () => {
  const { user } = useAuth();

  if (!user) {
    return <p>Carregando perfil...</p>; // Or redirect, though ProtectedRoute should handle this
  }

  const handleCopyReferralLink = () => {
    navigator.clipboard.writeText(user.referralLink)
      .then(() => toast.success('Link de indicação copiado!'))
      .catch(err => toast.error('Falha ao copiar o link.'));
  };

  return (
    <div className="space-y-8">
      <header className="mb-6">
        <h1 className="text-3xl font-display font-bold text-primary">Meu Perfil</h1>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Info Card */}
        <div className="md:col-span-1">
          <Card className="text-center">
            <img 
              src={user.profilePictureUrl} 
              alt={user.name} 
              className="w-32 h-32 rounded-full mx-auto mb-4 shadow-md border-4 border-accent"
            />
            <h2 className="text-2xl font-display font-semibold text-primary">{user.name}</h2>
            <p className="text-secondary mb-1">{user.email}</p>
            <div className="mt-4 flex items-center justify-center text-accent">
              <PointsIcon className="w-6 h-6 mr-2" />
              <span className="text-xl font-bold">{user.points} Pontos</span>
            </div>
          </Card>
        </div>

        {/* Achievements and Referral */}
        <div className="md:col-span-2 space-y-6">
          <Card title="Minhas Conquistas">
            {user.achievements.length > 0 ? (
              <ul className="space-y-3 max-h-60 overflow-y-auto pr-2">
                {user.achievements.slice().reverse().map(ach => ( // Show newest first
                  <li key={ach.id} className="flex items-center p-3 bg-lightBg rounded-md shadow-sm">
                    <span className="text-2xl mr-3">{ach.icon || <BadgeIcon className="w-6 h-6 text-accent"/>}</span>
                    <div>
                      <h4 className="font-semibold text-primary">{ach.name}</h4>
                      <p className="text-sm text-secondary">{ach.description}</p>
                      <p className="text-xs text-gray-500">Conquistado em: {new Date(ach.dateEarned).toLocaleDateString()}</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-secondary">Continue participando para desbloquear conquistas!</p>
            )}
          </Card>

          <Card title="Meu Link de Indicação">
            <p className="text-secondary mb-3">Compartilhe seu link exclusivo para ganhar pontos quando seus amigos se cadastrarem e matricularem!</p>
            <div className="flex items-center space-x-2 bg-gray-100 p-3 rounded-md">
              <ShareIcon className="w-5 h-5 text-primary"/>
              <input 
                type="text" 
                readOnly 
                value={user.referralLink} 
                className="flex-grow bg-transparent text-sm text-darkText focus:outline-none"
              />
              <Button onClick={handleCopyReferralLink} variant="accent" size="sm" aria-label="Copiar link">
                <CopyIcon className="w-5 h-5"/>
              </Button>
            </div>
             <div className="mt-4 flex space-x-2">
                <Button 
                    variant="primary" 
                    size="sm" 
                    onClick={() => window.open(`https://wa.me/?text=Olá! Quero te convidar para o Portal do Aluno Conectado. Use meu link: ${encodeURIComponent(user.referralLink)}`, '_blank')}
                >
                    WhatsApp
                </Button>
                 <Button 
                    variant="secondary" 
                    size="sm" 
                    onClick={() => window.open(`https://t.me/share/url?url=${encodeURIComponent(user.referralLink)}&text=Olá! Quero te convidar para o Portal do Aluno Conectado.`, '_blank')}
                 >
                    Telegram
                 </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
