
import React, { useEffect, useState } from 'react';
import { Campaign, GamificationActionType } from '../../types';
import { fetchMockCampaigns, fetchMockCampaignById } from './mockCampaignService';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import Modal from '../../components/common/Modal';
import { useGamification } from '../gamification/GamificationContext';
import { MegaphoneIcon, CalendarIcon, PointsIcon } from '../../components/icons/FluentIcons';

const CampaignCard: React.FC<{ campaign: Campaign; onParticipate: (campaign: Campaign) => void; isCompleted: boolean }> = ({ campaign, onParticipate, isCompleted }) => {
  return (
    <Card className="flex flex-col h-full hover:shadow-xl transition-shadow duration-200">
      <img src={campaign.coverImageUrl} alt={campaign.title} className="w-full h-48 object-cover" />
      <div className="p-4 flex-grow">
        <h3 className="text-xl font-display font-semibold text-primary mb-2">{campaign.title}</h3>
        <p className="text-sm text-secondary mb-3 h-20 overflow-hidden">{campaign.shortDescription}</p>
        <div className="text-xs text-gray-500 space-y-1">
            <div className="flex items-center">
                <CalendarIcon className="w-4 h-4 mr-1 text-secondary" />
                <span>Expira em: {new Date(campaign.expiryDate).toLocaleDateString()}</span>
            </div>
            <div className="flex items-center">
                <PointsIcon className="w-4 h-4 mr-1 text-accent" />
                <span>Ganha: {campaign.pointsToEarn} pontos</span>
            </div>
        </div>
      </div>
      <div className="p-4 border-t border-gray-200">
        <Button 
            variant="accent" 
            onClick={() => onParticipate(campaign)} 
            className="w-full"
            disabled={isCompleted}
        >
          {isCompleted ? 'Concluído' : 'Ver Detalhes e Participar'}
        </Button>
      </div>
    </Card>
  );
};


const CampaignsPage: React.FC = () => {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const { addPoints, getCampaignStatus } = useGamification();

  useEffect(() => {
    const loadCampaigns = async () => {
      setLoading(true);
      try {
        const data = await fetchMockCampaigns();
        setCampaigns(data);
      } catch (error) {
        console.error("Failed to load campaigns:", error);
      } finally {
        setLoading(false);
      }
    };
    loadCampaigns();
  }, []);

  const handleOpenCampaignDetails = async (campaign: Campaign) => {
    // Optionally fetch full details if not already loaded
    const fullCampaignDetails = await fetchMockCampaignById(campaign.id);
    setSelectedCampaign(fullCampaignDetails || campaign);
  };

  const handleCloseModal = () => {
    setSelectedCampaign(null);
  };

  const handleParticipate = async (campaign: Campaign) => {
    // For "Completar Perfil" campaign, it's just a visual cue or could trigger a navigation.
    // For other campaigns, it adds points.
    if (campaign.id === 'campaign5') { // "Conclua seu Perfil" campaign example
        // Maybe navigate to profile page or show a specific message
        // For simplicity, we'll just award points as if it's a generic campaign
         await addPoints(GamificationActionType.PROFILE_COMPLETION, campaign.id);
    } else {
        await addPoints(GamificationActionType.CAMPAIGN_INTERACTION, campaign.id);
    }
    handleCloseModal(); // Close modal after participation
  };


  if (loading) {
    return <LoadingSpinner text="Carregando campanhas..." />;
  }

  return (
    <div className="space-y-6">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-display font-bold text-primary flex items-center justify-center">
            <MegaphoneIcon className="w-10 h-10 mr-3 text-accent" />
            Campanhas de Engajamento
        </h1>
        <p className="text-secondary text-lg">Participe das nossas campanhas e ganhe pontos!</p>
      </header>

      {campaigns.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campaigns.map(campaign => (
            <CampaignCard 
                key={campaign.id} 
                campaign={campaign} 
                onParticipate={handleOpenCampaignDetails}
                isCompleted={getCampaignStatus(campaign.id)}
            />
          ))}
        </div>
      ) : (
        <Card>
          <p className="text-center text-secondary py-8">Nenhuma campanha ativa no momento. Volte em breve!</p>
        </Card>
      )}

      {selectedCampaign && (
        <Modal isOpen={!!selectedCampaign} onClose={handleCloseModal} title={selectedCampaign.title} size="lg">
          <div className="space-y-4">
            <img src={selectedCampaign.coverImageUrl} alt={selectedCampaign.title} className="w-full h-64 object-cover rounded-md" />
            <p className="text-secondary">{selectedCampaign.fullDescription}</p>
            <div>
                <h4 className="font-semibold text-primary">Ações Necessárias:</h4>
                <p className="text-secondary">{selectedCampaign.actionsRequired}</p>
            </div>
             <div className="text-sm text-gray-600 space-y-1">
                <div className="flex items-center">
                    <PointsIcon className="w-5 h-5 mr-2 text-accent" />
                    <span>Ganha: {selectedCampaign.pointsToEarn} pontos</span>
                </div>
                <div className="flex items-center">
                    <CalendarIcon className="w-5 h-5 mr-2 text-secondary" />
                    <span>Expira em: {new Date(selectedCampaign.expiryDate).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
                </div>
            </div>
          </div>
          <div className="mt-6 pt-4 border-t">
            <Button 
                variant="accent" 
                onClick={() => handleParticipate(selectedCampaign)}
                className="w-full"
                disabled={getCampaignStatus(selectedCampaign.id)}
            >
              {getCampaignStatus(selectedCampaign.id) ? 'Participação Concluída' : 'Confirmar Participação e Ganhar Pontos'}
            </Button>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default CampaignsPage;
