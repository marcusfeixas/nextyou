
import { Campaign } from '../../types';
import { PICSUM_CAMPAIGN_URL_PREFIX } from '../../constants';

const mockCampaigns: Campaign[] = [
  {
    id: 'campaign1',
    title: 'Participe do Webinar de Carreira',
    coverImageUrl: `${PICSUM_CAMPAIGN_URL_PREFIX}/webinar/600/300`,
    shortDescription: 'Aprenda como se destacar no mercado de trabalho com nossos especialistas.',
    fullDescription: 'Este webinar exclusivo cobrirá tópicos como criação de currículo, técnicas de entrevista e networking. Não perca a chance de impulsionar sua carreira! Para ganhar os pontos, assista ao webinar completo e responda a um breve quiz ao final.',
    expiryDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(), // 15 days from now
    pointsToEarn: 75,
    actionsRequired: 'Assistir ao webinar e responder o quiz.',
  },
  {
    id: 'campaign2',
    title: 'Semana da Inovação Tecnológica',
    coverImageUrl: `${PICSUM_CAMPAIGN_URL_PREFIX}/techweek/600/300`,
    shortDescription: 'Explore as últimas tendências em tecnologia e participe de workshops práticos.',
    fullDescription: 'Junte-se a nós para uma semana repleta de palestras, workshops e desafios sobre Inteligência Artificial, Desenvolvimento Web e Mobile, e Cibersegurança. Ganhe pontos participando de pelo menos 2 atividades.',
    expiryDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
    pointsToEarn: 120,
    actionsRequired: 'Participar de no mínimo 2 atividades da Semana da Inovação.',
  },
  {
    id: 'campaign3',
    title: 'Ação Social: Doe e Transforme Vidas',
    coverImageUrl: `${PICSUM_CAMPAIGN_URL_PREFIX}/socialaction/600/300`,
    shortDescription: 'Contribua com nossa campanha de arrecadação e faça a diferença na comunidade.',
    fullDescription: 'Estamos arrecadando alimentos não perecíveis e agasalhos para instituições de caridade locais. Sua contribuição é muito importante. Registre sua doação no ponto de coleta para ganhar os pontos.',
    expiryDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), // 10 days from now
    pointsToEarn: 50,
    actionsRequired: 'Realizar uma doação de alimentos ou agasalhos e registrar no local.',
  },
  {
    id: 'campaign4',
    title: 'Desafio de Programação Mensal',
    coverImageUrl: `${PICSUM_CAMPAIGN_URL_PREFIX}/codingchallenge/600/300`,
    shortDescription: 'Teste suas habilidades de codificação e concorra a prêmios.',
    fullDescription: 'Todo mês um novo desafio! Resolva o problema proposto utilizando sua linguagem de programação favorita. Submeta sua solução e ganhe pontos pela participação e acertos.',
    expiryDate: new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toISOString(), // End of current month
    pointsToEarn: 60,
    actionsRequired: 'Submeter uma solução válida para o desafio do mês.',
  },
   {
    id: 'campaign5',
    title: 'Conclua seu Perfil',
    coverImageUrl: `${PICSUM_CAMPAIGN_URL_PREFIX}/profilecomplete/600/300`,
    shortDescription: 'Complete todas as seções do seu perfil para ganhar pontos extras.',
    fullDescription: 'Um perfil completo ajuda a instituição a te conhecer melhor e a oferecer oportunidades mais personalizadas. Verifique se todas as informações estão atualizadas.',
    expiryDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString(), // 60 days from now
    pointsToEarn: 30, // Corresponds to PROFILE_COMPLETION points
    actionsRequired: 'Preencher todos os campos obrigatórios e opcionais do seu perfil de aluno.',
  },
];

export const fetchMockCampaigns = (): Promise<Campaign[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate filtering out expired campaigns (though not strictly necessary for this mock)
      const activeCampaigns = mockCampaigns.filter(c => new Date(c.expiryDate) > new Date());
      resolve(JSON.parse(JSON.stringify(activeCampaigns))); // Deep copy
    }, 500);
  });
};

export const fetchMockCampaignById = (id: string): Promise<Campaign | undefined> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(JSON.parse(JSON.stringify(mockCampaigns.find(c => c.id === id))));
    }, 300);
  });
};
