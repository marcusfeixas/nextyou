
import React, { createContext, useState, useEffect, useCallback } from 'react';
import { User, GamificationActionType } from '../../types';
import { mockLogin, mockLogout, getMockUser, initializeMockUser } from './mockAuthService'; // Will create this
import { GAMIFICATION_ACTIONS_CONFIG, MOCK_USER_ID, PICSUM_PROFILE_URL } from '../../constants';

interface AuthContextType {
  user: User | null;
  login: () => Promise<User | null>;
  logout: () => Promise<void>;
  loadingAuth: boolean;
  updateUserPoints: (pointsToAdd: number) => void;
  addAchievement: (achievement: { id: string; name: string; description: string; dateEarned: string; icon?: string }) => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  const updateUserPoints = useCallback((pointsToAdd: number) => {
    setUser(currentUser => {
      if (!currentUser) return null;
      const updatedUser = { ...currentUser, points: currentUser.points + pointsToAdd };
      localStorage.setItem(`user_${currentUser.id}`, JSON.stringify(updatedUser));
      return updatedUser;
    });
  }, []);
  
  const addAchievement = useCallback((achievement: { id: string; name: string; description: string; dateEarned: string; icon?: string }) => {
    setUser(currentUser => {
      if (!currentUser) return null;
      const updatedUser = { ...currentUser, achievements: [...currentUser.achievements, achievement] };
      localStorage.setItem(`user_${currentUser.id}`, JSON.stringify(updatedUser));
      return updatedUser;
    });
  }, []);


  useEffect(() => {
    // Initialize mock user data if it doesn't exist
    initializeMockUser();
    
    // Check for persisted login state (e.g., from localStorage)
    const storedUser = getMockUser(MOCK_USER_ID); // Simulates checking a session
    if (storedUser) {
      setUser(storedUser);
    }
    setLoadingAuth(false);
  }, []);

  const login = async (): Promise<User | null> => {
    setLoadingAuth(true);
    const loggedInUser = await mockLogin('testuser@example.com', 'password'); // Params are illustrative for mock
    if (loggedInUser) {
      // Check for first login points
      const isFirstLogin = !localStorage.getItem(`firstLoginAwarded_${loggedInUser.id}`);
      if (isFirstLogin) {
        const firstLoginAction = GAMIFICATION_ACTIONS_CONFIG[GamificationActionType.FIRST_LOGIN];
        loggedInUser.points += firstLoginAction.points;
        loggedInUser.achievements.push({
            id: `ach_${Date.now()}`,
            name: "Bem-vindo(a)!",
            description: firstLoginAction.description,
            dateEarned: new Date().toISOString(),
            icon: "🎉"
        });
        localStorage.setItem(`firstLoginAwarded_${loggedInUser.id}`, 'true');
      }
      localStorage.setItem(`user_${loggedInUser.id}`, JSON.stringify(loggedInUser)); // Persist user
      setUser(loggedInUser);
    }
    setLoadingAuth(false);
    return loggedInUser;
  };

  const logout = async (): Promise<void> => {
    setLoadingAuth(true);
    await mockLogout();
    if(user) {
        localStorage.removeItem(`user_${user.id}_completed_campaigns`);
        localStorage.removeItem(`user_${user.id}_last_daily_login`);
    }
    setUser(null);
    setLoadingAuth(false);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loadingAuth, updateUserPoints, addAchievement }}>
      {children}
    </AuthContext.Provider>
  );
};
