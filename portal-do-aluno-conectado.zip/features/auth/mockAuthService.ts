
import { User } from '../../types';
import { MOCK_USER_ID, PICSUM_PROFILE_URL } from '../../constants';

// Helper to get referral link
const generateReferralLink = (name: string): string => {
  const slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
  const randomSuffix = Math.random().toString(36).substring(2, 7);
  return `https://escola.com/indicacao?ref=${slug}${randomSuffix}`;
};

// Initialize mock user if not present in localStorage
export const initializeMockUser = (): void => {
  const existingUser = localStorage.getItem(`user_${MOCK_USER_ID}`);
  if (!existingUser) {
    const mockUser: User = {
      id: MOCK_USER_ID,
      name: 'Aluno Exemplo',
      email: 'aluno.exemplo@escola.com',
      profilePictureUrl: PICSUM_PROFILE_URL,
      points: 0, // Initial points
      referralLink: generateReferralLink('Aluno Exemplo'),
      achievements: [],
    };
    localStorage.setItem(`user_${MOCK_USER_ID}`, JSON.stringify(mockUser));
  }
};

export const mockLogin = (email?: string, password?: string): Promise<User | null> => {
  // In a real OAuth flow, you'd redirect to Google, then handle the callback.
  // Here, we simulate a successful login and return a mock user.
  // The email/password params are just for show, not used for Google OAuth.
  return new Promise((resolve) => {
    setTimeout(() => {
      const userDataString = localStorage.getItem(`user_${MOCK_USER_ID}`);
      if (userDataString) {
        const user: User = JSON.parse(userDataString);
        // Simulate pulling fresh data or just returning stored
        resolve({
            ...user,
            name: user.name || "Usuário Google", // Fallback name
            email: user.email || "usuario.google@example.com", // Fallback email
            profilePictureUrl: user.profilePictureUrl || PICSUM_PROFILE_URL, // Fallback picture
        });
      } else {
        // This case should ideally not happen if initializeMockUser works
        const newUser: User = {
            id: MOCK_USER_ID,
            name: "Usuário Google",
            email: "usuario.google@example.com",
            profilePictureUrl: PICSUM_PROFILE_URL,
            points: 0,
            referralLink: generateReferralLink("Usuário Google"),
            achievements: [],
        };
        localStorage.setItem(`user_${MOCK_USER_ID}`, JSON.stringify(newUser));
        resolve(newUser);
      }
    }, 1000); // Simulate network delay
  });
};

export const mockLogout = (): Promise<void> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Here you might clear session cookies or tokens
      // For this mock, we don't need to do much as state is managed in AuthContext
      resolve();
    }, 500);
  });
};

// Utility to get a mock user, e.g., on app load to check for existing session
export const getMockUser = (userId: string): User | null => {
  const userDataString = localStorage.getItem(`user_${userId}`);
  if (userDataString) {
    return JSON.parse(userDataString) as User;
  }
  return null;
};
