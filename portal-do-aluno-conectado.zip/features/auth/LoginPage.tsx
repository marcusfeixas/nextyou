
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './useAuth';
import { APP_NAME, ROUTES } from '../../constants';
import Button from '../../components/common/Button';
import { GoogleIcon } from '../../components/icons/FluentIcons'; // Placeholder for Google Icon
import { toast } from 'react-toastify';

const LoginPage: React.FC = () => {
  const { login, user, loadingAuth } = useAuth();
  const navigate = useNavigate();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  useEffect(() => {
    if (user && !loadingAuth) {
      navigate(ROUTES.DASHBOARD);
    }
  }, [user, loadingAuth, navigate]);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const loggedInUser = await login();
      if (loggedInUser) {
        toast.success(`Bem-vindo(a) de volta, ${loggedInUser.name}!`);
        navigate(ROUTES.DASHBOARD);
      } else {
        toast.error('Falha no login. Tente novamente.');
      }
    } catch (error) {
      console.error("Login failed:", error);
      toast.error('Ocorreu um erro durante o login.');
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  // Prevent rendering login page if already authenticated and not loading
  if (user && !loadingAuth) {
    return null; 
  }

  // Show loading spinner while auth state is being determined or during login
  if (loadingAuth || isLoggingIn) {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-lightBg p-6">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary"></div>
            <p className="mt-4 text-secondary text-lg">
                {isLoggingIn ? "Entrando..." : "Verificando autenticação..."}
            </p>
        </div>
    );
  }


  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-primary to-blue-700 p-6">
      <div className="w-full max-w-md p-8 bg-lightText shadow-2xl rounded-xl text-center">
        <img src="https://picsum.photos/seed/logo/150/150" alt="Logo da Instituição" className="mx-auto mb-6 rounded-full shadow-md" />
        <h1 className="text-4xl font-display font-bold text-primary mb-3">{APP_NAME}</h1>
        <p className="text-secondary text-lg mb-8">Conecte-se, aprenda e cresça.</p>
        
        <Button 
          onClick={handleLogin}
          variant="outline"
          size="lg"
          className="w-full border-gray-300 hover:bg-gray-100 text-darkText"
          leftIcon={<GoogleIcon className="w-6 h-6" />}
          isLoading={isLoggingIn}
          disabled={isLoggingIn}
        >
          Entrar com Google
        </Button>

        <p className="mt-8 text-xs text-gray-500">
          Ao continuar, você concorda com nossos <a href="#" className="text-primary hover:underline">Termos de Serviço</a> e <a href="#" className="text-primary hover:underline">Política de Privacidade</a>.
        </p>
      </div>
       <footer className="absolute bottom-4 text-center w-full">
        <p className="text-sm text-gray-300">© ${new Date().getFullYear()} {APP_NAME}. Uma plataforma inovadora.</p>
      </footer>
    </div>
  );
};

export default LoginPage;
