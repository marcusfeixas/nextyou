
import { Referral, ReferralStatus, User, GamificationActionType } from '../../types';
import { MOCK_USER_ID } from '../../constants';
import { awardMockPoints } from '../gamification/mockGamificationService';

let mockReferrals: Referral[] = [
  { id: 'ref1', friendEmail: 'amigo1@example.com', status: ReferralStatus.REGISTERED, dateInvited: new Date(Date.now() - 5*24*60*60*1000).toISOString(), dateStatusChanged: new Date(Date.now() - 2*24*60*60*1000).toISOString() },
  { id: 'ref2', friendEmail: 'amigo2@example.com', status: ReferralStatus.INVITED, dateInvited: new Date(Date.now() - 3*24*60*60*1000).toISOString(), dateStatusChanged: new Date(Date.now() - 3*24*60*60*1000).toISOString() },
  { id: 'ref3', friendEmail: 'amigo3@example.com', status: ReferralStatus.ENROLLED, dateInvited: new Date(Date.now() - 10*24*60*60*1000).toISOString(), dateStatusChanged: new Date(Date.now() - 1*24*60*60*1000).toISOString() },
  { id: 'ref4', friendEmail: 'visitante@example.com', status: ReferralStatus.VISITED, dateInvited: new Date(Date.now() - 1*24*60*60*1000).toISOString(), dateStatusChanged: new Date(Date.now() - 0.5*24*60*60*1000).toISOString() }
];

// This should be tied to the logged-in user, but for mock, we'll assume all referrals belong to MOCK_USER_ID
// In a real app, referrals would be stored with a referrerUserId.

export const fetchMockReferrals = (userId: string): Promise<Referral[]> => {
  return new Promise((resolve) => {
    // Filter referrals by userId if a real backend were used.
    // For now, returning all for MOCK_USER_ID for simplicity.
    if (userId === MOCK_USER_ID) {
      setTimeout(() => resolve(JSON.parse(JSON.stringify(mockReferrals))), 500);
    } else {
      setTimeout(() => resolve([]), 500);
    }
  });
};

export const sendMockReferralInvite = (userId: string, friendEmails: string[]): Promise<{ Succeeded: string[], Failed: string[] }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const newReferrals: Referral[] = [];
      const Succeeded: string[] = [];
      const Failed: string[] = [];

      friendEmails.forEach(email => {
        if (mockReferrals.find(r => r.friendEmail === email)) {
            // Simulate failure if email already invited, or some other validation
            Failed.push(email);
            return;
        }
        const newReferral: Referral = {
          id: `ref${Date.now()}${Math.random().toString(16).slice(2)}`,
          friendEmail: email,
          status: ReferralStatus.INVITED,
          dateInvited: new Date().toISOString(),
          dateStatusChanged: new Date().toISOString(),
        };
        newReferrals.push(newReferral);
        Succeeded.push(email);
      });
      mockReferrals = [...mockReferrals, ...newReferrals];
      resolve({Succeeded, Failed});
    }, 800);
  });
};

// Simulate a friend registering or enrolling through a referral link
// This would typically be triggered on the backend when a new user signs up with a ref code.
export const simulateReferralStatusChange = async (referralId: string, newStatus: ReferralStatus, referrerUserId: string): Promise<Referral | null> => {
    const referralIndex = mockReferrals.findIndex(r => r.id === referralId);
    if (referralIndex === -1) return null;

    const oldStatus = mockReferrals[referralIndex].status;
    mockReferrals[referralIndex].status = newStatus;
    mockReferrals[referralIndex].dateStatusChanged = new Date().toISOString();

    // Award points based on status change
    if (newStatus === ReferralStatus.REGISTERED && oldStatus !== ReferralStatus.REGISTERED && oldStatus !== ReferralStatus.ENROLLED) {
        await awardMockPoints(referrerUserId, 100); // Points for REFERRAL_REGISTERED
    } else if (newStatus === ReferralStatus.ENROLLED && oldStatus !== ReferralStatus.ENROLLED) {
        await awardMockPoints(referrerUserId, 500); // Points for REFERRAL_ENROLLED
        // If they skipped REGISTERED status, also give those points.
        if (oldStatus !== ReferralStatus.REGISTERED) {
             await awardMockPoints(referrerUserId, 100);
        }
    }
    return JSON.parse(JSON.stringify(mockReferrals[referralIndex]));
};

// Example function to trigger status change for demo
export const DEMO_upgradeReferralStatus = async (email: string, newStatus: ReferralStatus): Promise<Referral | null> => {
    const referral = mockReferrals.find(r => r.friendEmail === email);
    if (referral) {
        return simulateReferralStatusChange(referral.id, newStatus, MOCK_USER_ID);
    }
    return null;
}
