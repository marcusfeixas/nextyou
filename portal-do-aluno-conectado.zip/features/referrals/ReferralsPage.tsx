
import React, { useEffect, useState } from 'react';
import { Referral, ReferralStatus, GamificationActionType } from '../../types';
import { fetchMockReferrals, sendMockReferralInvite, DEMO_upgradeReferralStatus } from './mockReferralService';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import TextInput from '../../components/common/TextInput';
import { useAuth } from '../auth/useAuth';
import { useGamification } from '../gamification/GamificationContext';
import { toast } from 'react-toastify';
import { UserGroupIcon, ShareIcon, CopyIcon, EmailIcon } from '../../components/icons/FluentIcons';

const ReferralStatusPill: React.FC<{ status: ReferralStatus }> = ({ status }) => {
  const statusColors: Record<ReferralStatus, string> = {
    [ReferralStatus.INVITED]: 'bg-blue-100 text-blue-700',
    [ReferralStatus.VISITED]: 'bg-yellow-100 text-yellow-700',
    [ReferralStatus.REGISTERED]: 'bg-green-100 text-green-700',
    [ReferralStatus.ENROLLED]: 'bg-teal-100 text-teal-700',
  };
  return (
    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusColors[status]}`}>
      {status}
    </span>
  );
};

const ReferralsPage: React.FC = () => {
  const { user } = useAuth();
  const { addPoints } = useGamification();
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);
  const [inviteEmails, setInviteEmails] = useState<string>('');
  const [isSendingInvites, setIsSendingInvites] = useState(false);

  useEffect(() => {
    if (user) {
      const loadReferrals = async () => {
        setLoading(true);
        try {
          const data = await fetchMockReferrals(user.id);
          setReferrals(data);
        } catch (error) {
          console.error("Failed to load referrals:", error);
          toast.error("Erro ao carregar suas indicações.");
        } finally {
          setLoading(false);
        }
      };
      loadReferrals();
    }
  }, [user]);

  const handleCopyReferralLink = () => {
    if (user?.referralLink) {
      navigator.clipboard.writeText(user.referralLink)
        .then(() => toast.success('Link de indicação copiado!'))
        .catch(err => toast.error('Falha ao copiar o link.'));
    }
  };

  const handleInviteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !inviteEmails.trim()) return;

    setIsSendingInvites(true);
    const emailsArray = inviteEmails.split(',').map(email => email.trim()).filter(email => email);
    
    try {
      const result = await sendMockReferralInvite(user.id, emailsArray);
      if (result.Succeeded.length > 0) {
        toast.success(`${result.Succeeded.length} convite(s) enviado(s) com sucesso!`);
         // Fetch updated referrals list
        const updatedData = await fetchMockReferrals(user.id);
        setReferrals(updatedData);
      }
      if (result.Failed.length > 0) {
        toast.warn(`${result.Failed.length} convite(s) falharam (ex: e-mail já convidado).`);
      }
      setInviteEmails('');
    } catch (error) {
      console.error("Failed to send invites:", error);
      toast.error("Erro ao enviar convites.");
    } finally {
      setIsSendingInvites(false);
    }
  };

  // DEMO function to simulate status changes and point awarding
  const handleDemoStatusChange = async (referral: Referral, newStatus: ReferralStatus) => {
    if (!user) return;
    try {
        const updatedReferral = await DEMO_upgradeReferralStatus(referral.friendEmail, newStatus);
        if (updatedReferral) {
            setReferrals(prev => prev.map(r => r.id === updatedReferral.id ? updatedReferral : r));
            // Points are awarded within mockGamificationService through useAuth updateUserPoints, but let's confirm here via GamificationContext
            if (newStatus === ReferralStatus.REGISTERED && referral.status !== ReferralStatus.REGISTERED && referral.status !== ReferralStatus.ENROLLED) {
                 await addPoints(GamificationActionType.REFERRAL_REGISTERED);
            } else if (newStatus === ReferralStatus.ENROLLED && referral.status !== ReferralStatus.ENROLLED) {
                await addPoints(GamificationActionType.REFERRAL_ENROLLED);
                 if (referral.status !== ReferralStatus.REGISTERED) { // Also award registered if skipped
                    await addPoints(GamificationActionType.REFERRAL_REGISTERED);
                 }
            }
            toast.success(`Status de ${referral.friendEmail} atualizado para ${newStatus}.`);
        }
    } catch (error) {
        console.error("Demo status change failed:", error);
        toast.error("Falha ao simular mudança de status.");
    }
  };


  if (loading) {
    return <LoadingSpinner text="Carregando programa de indicação..." />;
  }
  
  if (!user) {
    return <p>Por favor, faça login para acessar o programa de indicação.</p>;
  }

  return (
    <div className="space-y-8">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-display font-bold text-primary flex items-center justify-center">
            <UserGroupIcon className="w-10 h-10 mr-3 text-accent" />
            Indique e Ganhe
        </h1>
        <p className="text-secondary text-lg">Convide seus amigos e ganhe pontos por cada indicação bem-sucedida!</p>
      </header>

      <Card title="Seu Link de Indicação Exclusivo">
        <p className="text-secondary mb-3">Compartilhe este link com seus amigos. Você ganhará <strong>100 pontos</strong> quando um amigo se cadastrar e mais <strong>500 pontos</strong> quando ele se matricular!</p>
        <div className="flex items-center space-x-2 bg-gray-100 p-3 rounded-md mb-4">
          <ShareIcon className="w-5 h-5 text-primary"/>
          <input 
            type="text" 
            readOnly 
            value={user.referralLink} 
            className="flex-grow bg-transparent text-sm text-darkText focus:outline-none"
          />
          <Button onClick={handleCopyReferralLink} variant="accent" size="sm" aria-label="Copiar link">
            <CopyIcon className="w-5 h-5"/>
          </Button>
        </div>
        <div className="flex space-x-2">
            <Button 
                variant="primary" 
                size="sm" 
                onClick={() => window.open(`https://wa.me/?text=Olá! Quero te convidar para o Portal do Aluno Conectado. Use meu link: ${encodeURIComponent(user.referralLink)}`, '_blank')}
            >
                WhatsApp
            </Button>
            <Button 
                variant="secondary" 
                size="sm" 
                onClick={() => window.open(`https://t.me/share/url?url=${encodeURIComponent(user.referralLink)}&text=Olá! Quero te convidar para o Portal do Aluno Conectado.`, '_blank')}
            >
                Telegram
            </Button>
            <Button 
                variant="outline" 
                size="sm" 
                onClick={() => window.location.href = `mailto:?subject=Convite para o Portal do Aluno Conectado&body=Olá! Quero te convidar para o Portal do Aluno Conectado. Use meu link: ${encodeURIComponent(user.referralLink)}`}
                leftIcon={<EmailIcon className="w-4 h-4"/>}
            >
                E-mail
            </Button>
        </div>
      </Card>

      <Card title="Convidar Amigos por E-mail">
        <form onSubmit={handleInviteSubmit} className="space-y-4">
          <TextInput
            label="E-mails dos amigos (separados por vírgula)"
            name="inviteEmails"
            type="text"
            placeholder="amigo1@email.com, amigo2@email.com"
            value={inviteEmails}
            onChange={(e) => setInviteEmails(e.target.value)}
            IconComponent={EmailIcon}
            required
          />
          <Button type="submit" variant="accent" isLoading={isSendingInvites} disabled={isSendingInvites || !inviteEmails.trim()}>
            Enviar Convites
          </Button>
        </form>
      </Card>

      <Card title="Status das Suas Indicações">
        {referrals.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">Amigo (E-mail)</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">Data do Convite</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider hidden md:table-cell">Última Atualização</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">Ações (Demo)</th>
                </tr>
              </thead>
              <tbody className="bg-lightText divide-y divide-gray-200">
                {referrals.map(referral => (
                  <tr key={referral.id}>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-darkText">{referral.friendEmail}</td>
                    <td className="px-4 py-3 whitespace-nowrap"><ReferralStatusPill status={referral.status} /></td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{new Date(referral.dateInvited).toLocaleDateString()}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 hidden md:table-cell">{new Date(referral.dateStatusChanged).toLocaleDateString()}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm space-x-1">
                        {referral.status === ReferralStatus.VISITED && (
                            <Button size="sm" variant="outline" onClick={() => handleDemoStatusChange(referral, ReferralStatus.REGISTERED)}>Simular Cadastro</Button>
                        )}
                        {referral.status === ReferralStatus.REGISTERED && (
                             <Button size="sm" variant="outline" onClick={() => handleDemoStatusChange(referral, ReferralStatus.ENROLLED)}>Simular Matrícula</Button>
                        )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-center text-secondary py-8">Você ainda não convidou nenhum amigo. Comece a indicar agora!</p>
        )}
      </Card>
    </div>
  );
};

export default ReferralsPage;
