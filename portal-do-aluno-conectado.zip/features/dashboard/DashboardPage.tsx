
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../auth/useAuth';
import { useGamification } from '../gamification/GamificationContext';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import { Campaign, JobPosting, LeaderboardEntry } from '../../types';
import { fetchMockCampaigns } from '../campaigns/mockCampaignService';
import { fetchMockJobs } from '../jobs/mockLinkedInService';
import { fetchMockLeaderboard } from '../gamification/mockGamificationService';
import { LeaderboardFilter } from '../../types';
import { ROUTES } from '../../constants';
import { PointsIcon, TrophyIcon, MegaphoneIcon, BriefcaseIcon, UserGroupIcon } from '../../components/icons/FluentIcons';
import LoadingSpinner from '../../components/common/LoadingSpinner';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const { points, achievements } = useGamification();
  const [loading, setLoading] = useState(true);
  const [recentCampaigns, setRecentCampaigns] = useState<Campaign[]>([]);
  const [recentJobs, setRecentJobs] = useState<JobPosting[]>([]);
  const [topLeaderboard, setTopLeaderboard] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [campaignsData, jobsData, leaderboardData] = await Promise.all([
          fetchMockCampaigns(),
          fetchMockJobs({}), // No filters for recent
          fetchMockLeaderboard(LeaderboardFilter.OVERALL)
        ]);
        setRecentCampaigns(campaignsData.slice(0, 2)); // Show 2 recent
        setRecentJobs(jobsData.jobs.slice(0, 2)); // Show 2 recent
        setTopLeaderboard(leaderboardData.slice(0, 3)); // Show top 3
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return <LoadingSpinner text="Carregando seu dashboard..." />;
  }

  if (!user) {
    return <p>Por favor, faça login para ver o dashboard.</p>; // Should be handled by ProtectedRoute
  }

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-display font-bold text-primary">Bem-vindo(a) de volta, {user.name.split(' ')[0]}!</h1>
        <p className="text-secondary text-lg">Aqui está um resumo da sua atividade e oportunidades.</p>
      </header>

      {/* Quick Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-primary to-blue-600 text-lightText">
          <div className="flex items-center">
            <PointsIcon className="w-12 h-12 text-accent mr-4" />
            <div>
              <p className="text-3xl font-bold">{points}</p>
              <p className="text-sm">Seus Pontos</p>
            </div>
          </div>
        </Card>
        <Card className="bg-gradient-to-r from-accent to-teal-600 text-lightText">
           <div className="flex items-center">
            <TrophyIcon className="w-12 h-12 text-primary mr-4" />
            <div>
              <p className="text-3xl font-bold">{achievements.length}</p>
              <p className="text-sm">Conquistas Desbloqueadas</p>
            </div>
          </div>
        </Card>
         <Card className="hover:shadow-xl transition-shadow">
          <Link to={ROUTES.REFERRALS} className="block">
            <div className="flex items-center">
              <UserGroupIcon className="w-12 h-12 text-orangeAccent mr-4" />
              <div>
                <p className="text-xl font-semibold text-primary">Indique um Amigo</p>
                <p className="text-sm text-secondary">Ganhe pontos por cada indicação!</p>
              </div>
            </div>
          </Link>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Campanhas Recentes */}
        <div className="lg:col-span-2">
          <Card title="Campanhas em Destaque">
            {recentCampaigns.length > 0 ? (
              <div className="space-y-4">
                {recentCampaigns.map(campaign => (
                  <div key={campaign.id} className="p-3 bg-lightBg rounded-md shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                        <div>
                            <h4 className="font-semibold text-primary">{campaign.title}</h4>
                            <p className="text-sm text-secondary">{campaign.shortDescription.substring(0,50)}...</p>
                        </div>
                        <Button variant="accent" size="sm" onClick={() => {/* Implement navigation or modal */}}>
                            Ver Detalhes
                        </Button>
                    </div>
                    <p className="text-xs text-accent mt-1">Ganha {campaign.pointsToEarn} pontos | Expira em: {new Date(campaign.expiryDate).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-secondary">Nenhuma campanha em destaque no momento.</p>
            )}
            <div className="mt-4 text-right">
              <Link to={ROUTES.CAMPAIGNS}>
                <Button variant="outline">Ver Todas Campanhas</Button>
              </Link>
            </div>
          </Card>
        </div>

        {/* Ranking Rápido */}
        <div>
          <Card title="Top 3 do Ranking">
            {topLeaderboard.length > 0 ? (
              <ul className="space-y-3">
                {topLeaderboard.map(entry => (
                  <li key={entry.userId} className="flex items-center p-2 bg-lightBg rounded-md">
                    <img src={entry.profilePictureUrl || `https://picsum.photos/seed/${entry.userId}/40/40`} alt={entry.name} className="w-10 h-10 rounded-full mr-3"/>
                    <div>
                      <p className="font-semibold text-primary">{entry.rank}. {entry.name}</p>
                      <p className="text-sm text-accent">{entry.score} pontos</p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-secondary">O ranking ainda está sendo formado.</p>
            )}
            <div className="mt-4 text-right">
              <Link to={ROUTES.LEADERBOARD}>
                <Button variant="outline">Ver Ranking Completo</Button>
              </Link>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Vagas Recentes */}
      <div>
         <Card title="Vagas Recentes Para Você">
            {recentJobs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recentJobs.map(job => (
                  <div key={job.id} className="p-3 bg-lightBg rounded-md shadow-sm hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-primary">{job.title}</h4>
                    <p className="text-sm text-secondary">{job.companyName} - {job.location}</p>
                    <div className="mt-2 flex justify-between items-center">
                        <span className="text-xs text-gray-500">Postado: {job.postDate}</span>
                        <a href={job.linkedInUrl} target="_blank" rel="noopener noreferrer">
                            <Button variant="accent" size="sm" rightIcon={<BriefcaseIcon className="w-4 h-4" />}>
                                Ver no LinkedIn
                            </Button>
                        </a>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-secondary">Nenhuma vaga recente encontrada com seu perfil.</p>
            )}
            <div className="mt-4 text-right">
              <Link to={ROUTES.JOBS}>
                <Button variant="outline">Explorar Mais Vagas</Button>
              </Link>
            </div>
          </Card>
      </div>

    </div>
  );
};

export default DashboardPage;
