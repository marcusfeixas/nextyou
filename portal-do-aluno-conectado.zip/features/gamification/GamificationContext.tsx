
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  GamificationState, GamificationContextType, GamificationActionType, 
  LeaderboardFilter, LeaderboardEntry, Achievement 
} from '../../types';
import { useAuth } from '../auth/useAuth';
import { GAMIFICATION_ACTIONS_CONFIG } from '../../constants';
import { fetchMockLeaderboard, awardMockPoints, checkDailyLoginStatus, recordDailyLogin } from './mockGamificationService';
import { toast } from 'react-toastify';

const GamificationContext = createContext<GamificationContextType | undefined>(undefined);

export const GamificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, updateUserPoints: updateUserAuthPoints, addAchievement: addUserAuthAchievement } = useAuth();
  
  const [state, setState] = useState<GamificationState>({
    points: 0,
    achievements: [],
    leaderboard: [],
    loadingLeaderboard: false,
    lastDailyLoginPointsAwarded: null,
  });

  const [completedCampaigns, setCompletedCampaigns] = useState<Set<string>>(new Set());

  // Load user-specific gamification data from localStorage or auth user on mount/user change
  useEffect(() => {
    if (user) {
      setState(prevState => ({
        ...prevState,
        points: user.points,
        achievements: user.achievements,
      }));
      // Load completed campaigns for this user
      const storedCompletedCampaigns = localStorage.getItem(`user_${user.id}_completed_campaigns`);
      if (storedCompletedCampaigns) {
        setCompletedCampaigns(new Set(JSON.parse(storedCompletedCampaigns)));
      }
      // Load last daily login date
      const storedLastDailyLogin = localStorage.getItem(`user_${user.id}_last_daily_login`);
       if (storedLastDailyLogin) {
        setState(prevState => ({ ...prevState, lastDailyLoginPointsAwarded: storedLastDailyLogin }));
      }
    } else { // User logged out, reset
      setState({
        points: 0,
        achievements: [],
        leaderboard: [],
        loadingLeaderboard: false,
        lastDailyLoginPointsAwarded: null,
      });
      setCompletedCampaigns(new Set());
    }
  }, [user]);

  // Handle daily login points
  useEffect(() => {
    if (user && user.id) {
        const today = new Date().toISOString().split('T')[0];
        if (state.lastDailyLoginPointsAwarded !== today) {
            const dailyLoginConfig = GAMIFICATION_ACTIONS_CONFIG[GamificationActionType.DAILY_LOGIN];
            if (checkDailyLoginStatus(user.id)) { // This function should check if points were already awarded today
                awardMockPoints(user.id, dailyLoginConfig.points).then(newTotalPoints => {
                    updateUserAuthPoints(dailyLoginConfig.points); // Update AuthContext user
                    setState(prevState => ({ ...prevState, points: newTotalPoints, lastDailyLoginPointsAwarded: today }));
                    recordDailyLogin(user.id); // Record that login points were awarded for today
                    localStorage.setItem(`user_${user.id}_last_daily_login`, today);
                    toast.info(`✨ Você ganhou ${dailyLoginConfig.points} pontos por login diário!`, { icon: "🎉" });
                });
            }
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, state.lastDailyLoginPointsAwarded, updateUserAuthPoints]);


  const addPoints = useCallback(async (actionType: GamificationActionType, campaignId?: string) => {
    if (!user) {
      toast.warn("Você precisa estar logado para ganhar pontos.");
      return;
    }

    const actionConfig = GAMIFICATION_ACTIONS_CONFIG[actionType];
    if (!actionConfig) {
      console.error(`Configuração para ação ${actionType} não encontrada.`);
      return;
    }

    // Handle campaign interaction uniqueness
    if (actionType === GamificationActionType.CAMPAIGN_INTERACTION) {
      if (!campaignId) {
        console.error("Campaign ID é necessário para interação de campanha.");
        return;
      }
      if (completedCampaigns.has(campaignId)) {
        toast.info("Você já ganhou pontos por esta campanha.");
        return;
      }
    }
    
    try {
      const newTotalPoints = await awardMockPoints(user.id, actionConfig.points);
      updateUserAuthPoints(actionConfig.points); // Update points in AuthContext
      setState(prevState => ({ ...prevState, points: newTotalPoints }));
      
      const achievement: Achievement = {
        id: `ach_${actionType}_${Date.now()}`,
        name: actionConfig.description,
        description: `Você ganhou ${actionConfig.points} pontos por: ${actionConfig.description}.`,
        dateEarned: new Date().toISOString(),
        icon: "🏆" // Generic icon, could be specific per action
      };
      addUserAuthAchievement(achievement); // Add achievement in AuthContext
      setState(prevState => ({ ...prevState, achievements: [...prevState.achievements, achievement] }));

      if (actionType === GamificationActionType.CAMPAIGN_INTERACTION && campaignId) {
        markCampaignAsCompleted(campaignId);
      }

      toast.success(`✨ Você ganhou ${actionConfig.points} pontos! Motivo: ${actionConfig.description}`, { icon: "🎉" });

    } catch (error) {
      console.error("Erro ao adicionar pontos:", error);
      toast.error("Ocorreu um erro ao tentar adicionar seus pontos.");
    }
  }, [user, completedCampaigns, updateUserAuthPoints, addUserAuthAchievement]);

  const fetchLeaderboard = useCallback(async (filter: LeaderboardFilter) => {
    if (!user) return;
    setState(prevState => ({ ...prevState, loadingLeaderboard: true }));
    try {
      const data = await fetchMockLeaderboard(filter);
      setState(prevState => ({ ...prevState, leaderboard: data, loadingLeaderboard: false }));
    } catch (error) {
      console.error("Erro ao buscar ranking:", error);
      toast.error("Não foi possível carregar o ranking.");
      setState(prevState => ({ ...prevState, loadingLeaderboard: false }));
    }
  }, [user]);

  const markCampaignAsCompleted = useCallback((campaignId: string) => {
    if (user) {
        setCompletedCampaigns(prev => {
            const newSet = new Set(prev);
            newSet.add(campaignId);
            localStorage.setItem(`user_${user.id}_completed_campaigns`, JSON.stringify(Array.from(newSet)));
            return newSet;
        });
    }
  }, [user]);

  const getCampaignStatus = useCallback((campaignId: string) => {
    return completedCampaigns.has(campaignId);
  }, [completedCampaigns]);


  return (
    <GamificationContext.Provider value={{ ...state, addPoints, fetchLeaderboard, markCampaignAsCompleted, getCampaignStatus }}>
      {children}
    </GamificationContext.Provider>
  );
};

export const useGamification = (): GamificationContextType => {
  const context = useContext(GamificationContext);
  if (context === undefined) {
    throw new Error('useGamification must be used within a GamificationProvider');
  }
  return context;
};
