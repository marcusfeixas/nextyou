
import { LeaderboardEntry, LeaderboardFilter, User, Achievement } from '../../types';
import { MOCK_USER_ID, PICSUM_PROFILE_URL } from '../../constants';

// Simulate a database of users for leaderboard
let mockUsersDb: User[] = [
  { id: MOCK_USER_ID, name: 'Aluno Exemplo', email: 'aluno.exemplo@escola.com', profilePictureUrl: PICSUM_PROFILE_URL, points: 575, referralLink: '', achievements: [] },
  { id: 'user2', name: 'Maria Silva', email: 'maria@escola.com', profilePictureUrl: 'https://picsum.photos/seed/maria/100/100', points: 1250, referralLink: '', achievements: [] },
  { id: 'user3', name: 'João Santos', email: 'joao@escola.com', profilePictureUrl: 'https://picsum.photos/seed/joao/100/100', points: 890, referralLink: '', achievements: [] },
  { id: 'user4', name: 'Ana Pereira', email: 'ana@escola.com', profilePictureUrl: 'https://picsum.photos/seed/ana/100/100', points: 420, referralLink: '', achievements: [] },
  { id: 'user5', name: 'Carlos Oliveira', email: 'carlos@escola.com', profilePictureUrl: 'https://picsum.photos/seed/carlos/100/100', points: 1500, referralLink: '', achievements: [] },
  // Add more mock users for a richer leaderboard
  ...Array.from({ length: 15 }, (_, i) => ({
    id: `user${i + 6}`,
    name: `Estudante ${i + 6}`,
    email: `estudante${i+6}@escola.com`,
    profilePictureUrl: `https://picsum.photos/seed/estudante${i+6}/100/100`,
    points: Math.floor(Math.random() * 1000) + 50,
    referralLink: '',
    achievements: []
  }))
];

// Ensure the MOCK_USER_ID user data is consistent with localStorage
const syncMockUserWithDb = () => {
    const storedUserData = localStorage.getItem(`user_${MOCK_USER_ID}`);
    if (storedUserData) {
        const storedUser: User = JSON.parse(storedUserData);
        const dbUserIndex = mockUsersDb.findIndex(u => u.id === MOCK_USER_ID);
        if (dbUserIndex !== -1) {
            mockUsersDb[dbUserIndex] = { ...mockUsersDb[dbUserIndex], ...storedUser };
        } else {
            mockUsersDb.push(storedUser);
        }
    }
};
syncMockUserWithDb(); // Call once at service load


export const awardMockPoints = (userId: string, pointsToAdd: number): Promise<number> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      syncMockUserWithDb(); // Ensure DB is up-to-date before modification
      const userIndex = mockUsersDb.findIndex(u => u.id === userId);
      if (userIndex !== -1) {
        mockUsersDb[userIndex].points += pointsToAdd;
        // Also update localStorage for the specific user
        const updatedUser = mockUsersDb[userIndex];
        localStorage.setItem(`user_${userId}`, JSON.stringify(updatedUser));
        resolve(mockUsersDb[userIndex].points);
      } else {
        reject(new Error("Usuário não encontrado para adicionar pontos."));
      }
    }, 300);
  });
};

export const addMockAchievement = (userId: string, achievement: Achievement): Promise<Achievement[]> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            syncMockUserWithDb();
            const userIndex = mockUsersDb.findIndex(u => u.id === userId);
            if (userIndex !== -1) {
                if (!mockUsersDb[userIndex].achievements.find(ach => ach.id === achievement.id)) {
                    mockUsersDb[userIndex].achievements.push(achievement);
                }
                const updatedUser = mockUsersDb[userIndex];
                localStorage.setItem(`user_${userId}`, JSON.stringify(updatedUser));
                resolve(mockUsersDb[userIndex].achievements);
            } else {
                reject(new Error("Usuário não encontrado para adicionar conquista."));
            }
        }, 200);
    });
};


export const fetchMockLeaderboard = (filter: LeaderboardFilter): Promise<LeaderboardEntry[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      syncMockUserWithDb(); // Ensure latest points are used
      let filteredUsers = [...mockUsersDb];

      // Filtering logic (simplified for mock)
      if (filter === LeaderboardFilter.CURRENT_MONTH || filter === LeaderboardFilter.CURRENT_WEEK) {
        // For mock, we don't have historical data, so just sort differently or show a subset
        // In a real app, this would query based on points earned in the period
        filteredUsers = filteredUsers.sort(() => 0.5 - Math.random()).slice(0, 15); // Randomize for demo
      }

      const leaderboard = filteredUsers
        .sort((a, b) => b.points - a.points)
        .slice(0, 20)
        .map((user, index) => ({
          rank: index + 1,
          userId: user.id,
          name: user.name,
          profilePictureUrl: user.profilePictureUrl,
          score: user.points,
        }));
      resolve(leaderboard);
    }, 700);
  });
};


// Daily Login Mock Logic
const DAILY_LOGIN_KEY_PREFIX = 'daily_login_awarded_';

export const checkDailyLoginStatus = (userId: string): boolean => {
  const today = new Date().toISOString().split('T')[0];
  const lastAwardedDate = localStorage.getItem(`${DAILY_LOGIN_KEY_PREFIX}${userId}`);
  return lastAwardedDate !== today; // True if not awarded today or never awarded
};

export const recordDailyLogin = (userId: string): void => {
  const today = new Date().toISOString().split('T')[0];
  localStorage.setItem(`${DAILY_LOGIN_KEY_PREFIX}${userId}`, today);
};
