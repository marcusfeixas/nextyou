
import React, { useEffect, useState } from 'react';
import { useGamification } from './GamificationContext';
import { LeaderboardEntry, LeaderboardFilter } from '../../types';
import Card from '../../components/common/Card';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import { TrophyIcon } from '../../components/icons/FluentIcons';

const LeaderboardPage: React.FC = () => {
  const { leaderboard, loadingLeaderboard, fetchLeaderboard } = useGamification();
  const [currentFilter, setCurrentFilter] = useState<LeaderboardFilter>(LeaderboardFilter.OVERALL);

  useEffect(() => {
    fetchLeaderboard(currentFilter);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentFilter]); // Removed fetchLeaderboard from dependencies to prevent loop, as it's stable

  const handleFilterChange = (filter: LeaderboardFilter) => {
    setCurrentFilter(filter);
  };

  return (
    <div className="space-y-6">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-display font-bold text-primary flex items-center justify-center">
          <TrophyIcon className="w-10 h-10 mr-3 text-accent" />
          Ranking de Alunos
        </h1>
        <p className="text-secondary text-lg">Veja quem são os alunos mais engajados!</p>
      </header>

      <Card>
        <div className="mb-6 flex flex-wrap justify-center gap-2">
          {Object.values(LeaderboardFilter).map(filterOption => (
            <button
              key={filterOption}
              onClick={() => handleFilterChange(filterOption)}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-150
                ${currentFilter === filterOption 
                  ? 'bg-primary text-lightText shadow-md' 
                  : 'bg-gray-200 text-secondary hover:bg-gray-300'}`}
            >
              {filterOption}
            </button>
          ))}
        </div>

        {loadingLeaderboard ? (
          <LoadingSpinner text="Carregando ranking..." />
        ) : leaderboard.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">
                    Posição
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">
                    Aluno
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-secondary uppercase tracking-wider">
                    Pontuação
                  </th>
                </tr>
              </thead>
              <tbody className="bg-lightText divide-y divide-gray-200">
                {leaderboard.map((entry: LeaderboardEntry, index: number) => (
                  <tr key={entry.userId} className={index < 3 ? 'bg-yellow-50' : (index % 2 === 0 ? 'bg-lightText' : 'bg-gray-50')}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`text-lg font-bold ${
                        entry.rank === 1 ? 'text-yellow-500' :
                        entry.rank === 2 ? 'text-gray-500' :
                        entry.rank === 3 ? 'text-orange-500' : 'text-primary'
                      }`}>
                        {entry.rank}°
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img className="h-10 w-10 rounded-full object-cover" src={entry.profilePictureUrl || `https://picsum.photos/seed/${entry.userId}/40/40`} alt={entry.name} />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-darkText">{entry.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-accent font-semibold">{entry.score} pontos</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-center text-secondary py-8">Nenhum dado no ranking para este filtro.</p>
        )}
      </Card>
    </div>
  );
};

export default LeaderboardPage;
