
import React, { useEffect, useState, useCallback } from 'react';
import { JobPosting, JobContractType, JobFilters } from '../../types';
import { fetchMockJobs } from './mockLinkedInService';
import Card from '../../components/common/Card';
import Button from '../../components/common/Button';
import LoadingSpinner from '../../components/common/LoadingSpinner';
import TextInput from '../../components/common/TextInput';
import SelectInput from '../../components/common/SelectInput';
import { BriefcaseIcon, SearchIcon, FilterIcon, LocationMarkerIcon, CalendarIcon, ExternalLinkIcon, LinkedInIcon } from '../../components/icons/FluentIcons';

const JobCard: React.FC<{ job: JobPosting }> = ({ job }) => (
  <Card className="hover:shadow-xl transition-shadow duration-200 flex flex-col justify-between h-full">
    <div>
        <div className="flex items-start mb-3">
            {job.companyLogoUrl ? (
            <img src={job.companyLogoUrl} alt={`${job.companyName} logo`} className="w-12 h-12 rounded-md mr-3 object-contain" />
            ) : (
            <div className="w-12 h-12 rounded-md mr-3 bg-gray-200 flex items-center justify-center text-primary">
                <BriefcaseIcon className="w-6 h-6"/>
            </div>
            )}
            <div>
            <h3 className="text-lg font-display font-semibold text-primary leading-tight">{job.title}</h3>
            <p className="text-sm text-secondary">{job.companyName}</p>
            </div>
        </div>
    
        <div className="text-xs text-gray-500 space-y-1 mb-3">
            <div className="flex items-center">
                <LocationMarkerIcon className="w-4 h-4 mr-1 text-secondary" /> {job.location}
            </div>
            <div className="flex items-center">
                <BriefcaseIcon className="w-4 h-4 mr-1 text-secondary" /> {job.contractType}
            </div>
            <div className="flex items-center">
                <CalendarIcon className="w-4 h-4 mr-1 text-secondary" /> Postado: {job.postDate}
            </div>
        </div>
        {job.description && <p className="text-sm text-darkText mb-3 h-16 overflow-hidden">{job.description}</p>}
    </div>
    <a href={job.linkedInUrl} target="_blank" rel="noopener noreferrer" className="mt-auto block">
      <Button variant="accent" className="w-full" leftIcon={<LinkedInIcon className="w-5 h-5"/>}>
        Ver no LinkedIn
      </Button>
    </a>
  </Card>
);

const contractTypeOptions = [
  { value: '', label: 'Todos os Tipos' },
  { value: JobContractType.FULL_TIME, label: JobContractType.FULL_TIME },
  { value: JobContractType.PART_TIME, label: JobContractType.PART_TIME },
  { value: JobContractType.INTERNSHIP, label: JobContractType.INTERNSHIP },
  { value: JobContractType.REMOTE, label: 'Apenas Remoto' }, // Special handling for location also
];

const JobsPage: React.FC = () => {
  const [jobs, setJobs] = useState<JobPosting[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<JobFilters>({ searchTerm: '', location: '', contractType: '' });
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [showFilters, setShowFilters] = useState(false);


  const loadJobs = useCallback(async (pageToLoad: number, currentFilters: JobFilters) => {
    setLoading(true);
    try {
      const data = await fetchMockJobs(currentFilters, pageToLoad);
      setJobs(pageToLoad === 1 ? data.jobs : prevJobs => [...prevJobs, ...data.jobs]); // Append for infinite scroll, replace for new filter/page 1
      setTotalPages(data.totalPages);
    } catch (error) {
      console.error("Failed to load jobs:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadJobs(1, filters); // Load initially and on filter change (page reset to 1)
  }, [filters, loadJobs]);
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
    setCurrentPage(1); // Reset page on filter change
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadJobs(1, filters); // Explicitly trigger search
  };
  
  const loadMoreJobs = () => {
    if (currentPage < totalPages && !loading) {
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      loadJobs(nextPage, filters); // Load next page with current filters
    }
  };


  return (
    <div className="space-y-6">
      <header className="mb-6 text-center">
        <h1 className="text-4xl font-display font-bold text-primary flex items-center justify-center">
            <BriefcaseIcon className="w-10 h-10 mr-3 text-accent" />
            Portal de Vagas
        </h1>
        <p className="text-secondary text-lg">Encontre as melhores oportunidades de carreira aqui.</p>
      </header>

      <Card>
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 items-end border-b pb-6 mb-6">
            <TextInput
                label="Cargo, Habilidade ou Empresa"
                name="searchTerm"
                placeholder="Ex: Desenvolvedor React"
                value={filters.searchTerm || ''}
                onChange={handleFilterChange}
                IconComponent={SearchIcon}
            />
            <TextInput
                label="Localidade"
                name="location"
                placeholder="Ex: São Paulo ou Remoto"
                value={filters.location || ''}
                onChange={handleFilterChange}
                IconComponent={LocationMarkerIcon}
            />
            <SelectInput
                label="Tipo de Contrato"
                name="contractType"
                options={contractTypeOptions}
                value={filters.contractType || ''}
                onChange={handleFilterChange}
                IconComponent={BriefcaseIcon}
            />
            {/* <Button type="submit" variant="primary" className="md:col-span-3 w-full md:w-auto md:justify-self-start" isLoading={loading}>
                Buscar Vagas
            </Button> */}
        </form>
         <Button 
            onClick={() => setShowFilters(!showFilters)} 
            variant="outline" 
            className="md:hidden w-full mb-4"
            leftIcon={<FilterIcon className="w-5 h-5"/>}
        >
            {showFilters ? 'Esconder Filtros' : 'Mostrar Filtros'}
        </Button>


        {loading && jobs.length === 0 ? ( // Show main spinner only on initial load
          <LoadingSpinner text="Buscando vagas..." />
        ) : jobs.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs.map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        ) : (
          <div className="text-center py-10">
            <BriefcaseIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-secondary">Nenhuma vaga encontrada</h3>
            <p className="text-gray-500">Tente ajustar seus filtros ou volte mais tarde.</p>
          </div>
        )}

        {loading && jobs.length > 0 && <LoadingSpinner text="Carregando mais vagas..." />}

        {!loading && currentPage < totalPages && jobs.length > 0 && (
          <div className="mt-8 text-center">
            <Button variant="primary" onClick={loadMoreJobs} isLoading={loading}>
              Carregar Mais Vagas
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default JobsPage;
