
import { JobPosting, JobContractType, JobFilters } from '../../types';

const allMockJobs: JobPosting[] = [
  {
    id: 'job1',
    title: 'Desenvolvedor React Pleno',
    companyName: 'Tech Solutions Inc.',
    companyLogoUrl: 'https://picsum.photos/seed/techsolutions/50/50',
    location: 'São Paulo, SP',
    postDate: 'há 2 dias',
    contractType: JobContractType.FULL_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567890',
    description: 'Buscamos desenvolvedor React com experiência para se juntar à nossa equipe inovadora.'
  },
  {
    id: 'job2',
    title: 'Estágio em Marketing Digital',
    companyName: 'Connect Marketing',
    companyLogoUrl: 'https://picsum.photos/seed/connectmarketing/50/50',
    location: 'Remoto',
    postDate: 'há 5 horas',
    contractType: JobContractType.INTERNSHIP,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567891',
    description: 'Oportunidade de estágio para aprender e aplicar estratégias de marketing digital.'
  },
  {
    id: 'job3',
    title: 'Analista de Dados Júnior',
    companyName: 'Data Insights Ltda.',
    companyLogoUrl: 'https://picsum.photos/seed/datainsights/50/50',
    location: 'Rio de Janeiro, RJ',
    postDate: 'há 1 semana',
    contractType: JobContractType.FULL_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567892',
    description: 'Analise grandes volumes de dados e gere insights para nossos clientes.'
  },
  {
    id: 'job4',
    title: 'Engenheiro de Software Sênior (Node.js)',
    companyName: 'Future Systems',
    companyLogoUrl: 'https://picsum.photos/seed/futuresystems/50/50',
    location: 'Belo Horizonte, MG',
    postDate: 'ontem',
    contractType: JobContractType.FULL_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567893',
    description: 'Lidere o desenvolvimento de soluções backend escaláveis com Node.js.'
  },
  {
    id: 'job5',
    title: 'Designer UX/UI (Meio Período)',
    companyName: 'Creative Minds Studio',
    companyLogoUrl: 'https://picsum.photos/seed/creativeminds/50/50',
    location: 'Remoto',
    postDate: 'há 3 dias',
    contractType: JobContractType.PART_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567894',
    description: 'Crie interfaces intuitivas e visualmente atraentes para web e mobile.'
  },
  {
    id: 'job6',
    title: 'Especialista em Cibersegurança',
    companyName: 'SecureNet Global',
    companyLogoUrl: 'https://picsum.photos/seed/securenet/50/50',
    location: 'Brasília, DF',
    postDate: 'há 4 dias',
    contractType: JobContractType.FULL_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567895',
    description: 'Proteja nossos sistemas e dados contra ameaças cibernéticas.'
  },
   {
    id: 'job7',
    title: 'Desenvolvedor Full Stack (Python/Django)',
    companyName: 'InovaDev Software',
    companyLogoUrl: 'https://picsum.photos/seed/inovadev/50/50',
    location: 'Curitiba, PR',
    postDate: 'há 6 dias',
    contractType: JobContractType.FULL_TIME,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567896',
    description: 'Participe do ciclo completo de desenvolvimento de aplicações web.'
  },
  {
    id: 'job8',
    title: 'Estágio em Desenvolvimento Mobile (React Native)',
    companyName: 'AppFactory Co.',
    companyLogoUrl: 'https://picsum.photos/seed/appfactory/50/50',
    location: 'Remoto (Brasil)',
    postDate: 'há 1 dia',
    contractType: JobContractType.INTERNSHIP,
    linkedInUrl: 'https://www.linkedin.com/jobs/view/1234567897',
    description: 'Aprenda e contribua no desenvolvimento de aplicativos móveis multiplataforma.'
  }
];

// Paginate results
const PAGE_SIZE = 6;

export const fetchMockJobs = (
    filters: JobFilters, 
    page: number = 1
): Promise<{ jobs: JobPosting[], totalJobs: number, totalPages: number }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      let filteredJobs = allMockJobs;

      if (filters.searchTerm) {
        const term = filters.searchTerm.toLowerCase();
        filteredJobs = filteredJobs.filter(
          job =>
            job.title.toLowerCase().includes(term) ||
            job.companyName.toLowerCase().includes(term) ||
            (job.description && job.description.toLowerCase().includes(term))
        );
      }

      if (filters.location) {
        const loc = filters.location.toLowerCase();
        if (loc === 'remoto') {
            filteredJobs = filteredJobs.filter(job => job.location.toLowerCase().includes('remoto') || job.contractType === JobContractType.REMOTE);
        } else {
            filteredJobs = filteredJobs.filter(job => job.location.toLowerCase().includes(loc));
        }
      }
      
      // If filters.contractType is a truthy value (i.e., one of the enum values, not '' or undefined),
      // then filter by that contract type.
      if (filters.contractType) {
        filteredJobs = filteredJobs.filter(job => job.contractType === filters.contractType);
      }
      
      const totalJobs = filteredJobs.length;
      const totalPages = Math.ceil(totalJobs / PAGE_SIZE);
      const paginatedJobs = filteredJobs.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

      resolve({ jobs: JSON.parse(JSON.stringify(paginatedJobs)), totalJobs, totalPages });
    }, 800); // Simulate network delay
  });
};
