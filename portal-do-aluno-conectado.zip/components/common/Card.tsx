
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  actions?: React.ReactNode; // e.g., buttons at the bottom of the card
  onClick?: () => void;
}

const Card: React.FC<CardProps> = ({ children, className = '', title, actions, onClick }) => {
  const cardClasses = `bg-lightText shadow-lg rounded-lg overflow-hidden ${onClick ? 'cursor-pointer hover:shadow-xl transition-shadow duration-200' : ''} ${className}`;
  
  return (
    <div className={cardClasses} onClick={onClick}>
      {title && (
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-xl font-display font-semibold text-primary">{title}</h3>
        </div>
      )}
      <div className="px-6 py-4">
        {children}
      </div>
      {actions && (
        <div className="px-6 py-3 bg-gray-50 border-t border-gray-200 text-right">
          {actions}
        </div>
      )}
    </div>
  );
};

export default Card;
