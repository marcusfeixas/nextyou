
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../features/auth/useAuth';
import { APP_NAME, ROUTES } from '../../constants';
import { UserIcon, LogoutIcon, MenuIcon, XIcon, HomeIcon, TrophyIcon, MegaphoneIcon, UserGroupIcon, BriefcaseIcon } from '../icons/FluentIcons'; // Using new FluentIcons
import { useGamification } from '../../features/gamification/GamificationContext';
import { PointsIcon } from '../icons/FluentIcons';


const NavLink: React.FC<{ to: string; children: React.ReactNode; icon: React.ReactNode; onClick?: () => void }> = ({ to, children, icon, onClick }) => (
  <Link
    to={to}
    onClick={onClick}
    className="flex items-center px-3 py-2 text-lightText hover:bg-primary-dark rounded-md text-sm font-medium transition-colors duration-150"
    aria-current="page"
  >
    {icon}
    <span className="ml-2">{children}</span>
  </Link>
);

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const { points } = useGamification();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate(ROUTES.LOGIN);
  };

  if (!user) {
    return null; // Don't show navbar on login page or if no user
  }

  const navItems = [
    { to: ROUTES.DASHBOARD, label: "Dashboard", icon: <HomeIcon className="w-5 h-5" /> },
    { to: ROUTES.PROFILE, label: "Meu Perfil", icon: <UserIcon className="w-5 h-5" /> },
    { to: ROUTES.LEADERBOARD, label: "Ranking", icon: <TrophyIcon className="w-5 h-5" /> },
    { to: ROUTES.CAMPAIGNS, label: "Campanhas", icon: <MegaphoneIcon className="w-5 h-5" /> },
    { to: ROUTES.REFERRALS, label: "Indique e Ganhe", icon: <UserGroupIcon className="w-5 h-5" /> },
    { to: ROUTES.JOBS, label: "Vagas", icon: <BriefcaseIcon className="w-5 h-5" /> },
  ];

  return (
    <nav className="bg-primary shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to={ROUTES.DASHBOARD} className="flex-shrink-0 text-lightText font-display text-xl font-bold">
              {APP_NAME}
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              {navItems.map(item => (
                <NavLink key={item.to} to={item.to} icon={item.icon}>{item.label}</NavLink>
              ))}
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center text-lightText text-sm">
                <PointsIcon className="w-5 h-5 mr-1 text-accent" /> {points} Pontos
            </div>
            <div className="relative">
                 <button onClick={handleLogout} className="flex items-center p-2 text-lightText hover:bg-primary-dark rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-primary focus:ring-lightText transition-colors duration-150">
                    <LogoutIcon className="h-6 w-6" /> <span className="ml-1 text-sm">Sair</span>
                 </button>
            </div>
          </div>
          <div className="md:hidden flex items-center">
             <div className="flex items-center text-lightText text-sm mr-2">
                <PointsIcon className="w-5 h-5 mr-1 text-accent" /> {points}
            </div>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-lightText hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-inset focus:ring-lightText"
              aria-expanded="false"
            >
              <span className="sr-only">Abrir menu principal</span>
              {mobileMenuOpen ? <XIcon className="block h-6 w-6" /> : <MenuIcon className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map(item => (
              <NavLink key={item.to} to={item.to} icon={item.icon} onClick={() => setMobileMenuOpen(false)}>{item.label}</NavLink>
            ))}
          </div>
          <div className="pt-4 pb-3 border-t border-primary-dark">
            <div className="flex items-center px-5">
              <div className="flex-shrink-0">
                <img className="h-10 w-10 rounded-full" src={user.profilePictureUrl} alt="Foto do perfil" />
              </div>
              <div className="ml-3">
                <div className="text-base font-medium text-lightText">{user.name}</div>
                <div className="text-sm font-medium text-gray-300">{user.email}</div>
              </div>
            </div>
            <div className="mt-3 px-2 space-y-1">
              <button
                onClick={() => { handleLogout(); setMobileMenuOpen(false); }}
                className="w-full flex items-center px-3 py-2 text-base font-medium text-lightText hover:bg-primary-dark rounded-md transition-colors duration-150"
              >
                <LogoutIcon className="w-5 h-5" />
                <span className="ml-2">Sair</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
