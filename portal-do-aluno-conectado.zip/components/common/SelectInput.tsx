
import React from 'react';

interface SelectOption {
  value: string | number;
  label: string;
}

interface SelectInputProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: SelectOption[];
  IconComponent?: React.FC<React.SVGProps<SVGSVGElement>>;
}

const SelectInput: React.FC<SelectInputProps> = ({ label, name, error, options, IconComponent, className, ...props }) => {
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={name} className="block text-sm font-medium text-secondary mb-1">
          {label}
        </label>
      )}
      <div className="relative rounded-md shadow-sm">
         {IconComponent && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <IconComponent className="h-5 w-5 text-gray-400" aria-hidden="true" />
            </div>
        )}
        <select
          id={name}
          name={name}
          className={`
            block w-full 
            ${IconComponent ? 'pl-10' : 'pl-3'}
            pr-10 py-2 
            border 
            ${error ? 'border-red-500 text-red-700 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 text-darkText focus:ring-primary focus:border-primary'} 
            rounded-md 
            shadow-sm 
            focus:outline-none 
            sm:text-sm
            ${className}
          `}
          {...props}
        >
          {options.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
};

export default SelectInput;
