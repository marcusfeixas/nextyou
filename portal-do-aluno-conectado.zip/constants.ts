
import { GamificationAction, GamificationActionType } from './types';

export const APP_NAME = "Portal do Aluno Conectado";

export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  PROFILE: '/profile',
  LEADERBOARD: '/leaderboard',
  CAMPAIGNS: '/campaigns',
  REFERRALS: '/referrals',
  JOBS: '/jobs',
};

// Gamification Points Configuration
export const GAMIFICATION_ACTIONS_CONFIG: Record<GamificationActionType, GamificationAction> = {
  [GamificationActionType.FIRST_LOGIN]: { actionType: GamificationActionType.FIRST_LOGIN, points: 50, description: "Primeiro login no app" },
  [GamificationActionType.PROFILE_COMPLETION]: { actionType: GamificationActionType.PROFILE_COMPLETION, points: 30, description: "Completar 100% do perfil" },
  [GamificationActionType.CAMPAIGN_INTERACTION]: { actionType: GamificationActionType.CAMPAIGN_INTERACTION, points: 20, description: "Interagir com uma campanha", limitPerCampaign: true },
  [GamificationActionType.REFERRAL_REGISTERED]: { actionType: GamificationActionType.REFERRAL_REGISTERED, points: 100, description: "Indicação com cadastro confirmado" },
  [GamificationActionType.REFERRAL_ENROLLED]: { actionType: GamificationActionType.REFERRAL_ENROLLED, points: 500, description: "Indicação efetivada (matrícula)" },
  [GamificationActionType.DAILY_LOGIN]: { actionType: GamificationActionType.DAILY_LOGIN, points: 5, description: "Login diário" },
};

export const MOCK_USER_ID = "user123"; // For mock services

export const PICSUM_PROFILE_URL = 'https://picsum.photos/seed/profile/100/100';
export const PICSUM_CAMPAIGN_URL_PREFIX = 'https://picsum.photos/seed';
