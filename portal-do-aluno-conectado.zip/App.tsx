
import React from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './features/auth/useAuth';
import LoginPage from './features/auth/LoginPage';
import Navbar from './components/common/Navbar';
import DashboardPage from './features/dashboard/DashboardPage';
import ProfilePage from './features/profile/ProfilePage';
import LeaderboardPage from './features/gamification/LeaderboardPage';
import CampaignsPage from './features/campaigns/CampaignsPage';
import ReferralsPage from './features/referrals/ReferralsPage';
import JobsPage from './features/jobs/JobsPage';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loadingAuth } = useAuth();
  if (loadingAuth) {
    // Optionally, render a loading spinner here
    return <div className="flex justify-center items-center h-screen"><p>Verificando autenticação...</p></div>;
  }
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

const AppLayout: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Outlet />
      </main>
      <footer className="bg-primary text-lightText text-center p-4">
        © ${new Date().getFullYear()} Portal do Aluno Conectado. Todos os direitos reservados.
      </footer>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/leaderboard" element={<LeaderboardPage />} />
          <Route path="/campaigns" element={<CampaignsPage />} />
          <Route path="/referrals" element={<ReferralsPage />} />
          <Route path="/jobs" element={<JobsPage />} />
          <Route path="/" element={<Navigate to="/dashboard" />} />
        </Route>
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <ToastContainer position="bottom-right" autoClose={3000} theme="colored" />
    </HashRouter>
  );
};

export default App;
