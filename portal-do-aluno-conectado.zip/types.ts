
export interface User {
  id: string;
  name: string;
  email: string;
  profilePictureUrl: string;
  points: number;
  referralLink: string;
  achievements: Achievement[];
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  dateEarned: string;
  icon?: string; // e.g., URL or identifier for an icon
}

export enum GamificationActionType {
  FIRST_LOGIN = 'FIRST_LOGIN',
  PROFILE_COMPLETION = 'PROFILE_COMPLETION', // Assuming there might be more fields later
  CAMPAIGN_INTERACTION = 'CAMPAIGN_INTERACTION',
  REFERRAL_REGISTERED = 'REFERRAL_REGISTERED',
  REFERRAL_ENROLLED = 'REFERRAL_ENROLLED',
  DAILY_LOGIN = 'DAILY_LOGIN',
}

export interface GamificationAction {
  actionType: GamificationActionType;
  points: number;
  description: string;
  limitPerCampaign?: boolean; // For CAMPAIGN_INTERACTION
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  profilePictureUrl?: string;
  score: number;
}

export enum LeaderboardFilter {
  OVERALL = 'Geral',
  CURRENT_MONTH = 'Mês Atual',
  CURRENT_WEEK = 'Semana Atual',
}

export interface Campaign {
  id: string;
  title: string;
  coverImageUrl: string;
  shortDescription: string;
  fullDescription: string;
  expiryDate: string;
  pointsToEarn: number;
  actionsRequired: string; // Text describing what to do
  isCompleted?: boolean; // For specific user
}

export enum ReferralStatus {
  INVITED = 'Convidado',
  VISITED = 'Visitou',
  REGISTERED = 'Cadastrado',
  ENROLLED = 'Matriculado',
}

export interface Referral {
  id: string;
  friendEmail: string;
  status: ReferralStatus;
  dateInvited: string;
  dateStatusChanged: string;
}

export interface JobPosting {
  id: string;
  title: string;
  companyName: string;
  companyLogoUrl?: string;
  location: string;
  postDate: string; // e.g., "há 2 dias" or ISO date
  contractType: JobContractType;
  linkedInUrl: string;
  description?: string; // Optional short description
}

export enum JobContractType {
  FULL_TIME = 'Integral',
  PART_TIME = 'Meio Período',
  INTERNSHIP = 'Estágio',
  REMOTE = 'Remoto', // Can also be a location aspect
}

export interface JobFilters {
  searchTerm?: string;
  location?: string;
  contractType?: JobContractType | '';
}

// For GamificationContext
export interface GamificationState {
  points: number;
  achievements: Achievement[];
  leaderboard: LeaderboardEntry[];
  loadingLeaderboard: boolean;
  lastDailyLoginPointsAwarded: string | null; // Store YYYY-MM-DD
}

export interface GamificationContextType extends GamificationState {
  addPoints: (action: GamificationActionType, campaignId?: string) => Promise<void>;
  fetchLeaderboard: (filter: LeaderboardFilter) => Promise<void>;
  markCampaignAsCompleted: (campaignId: string) => void; // UI helper, real logic in addPoints
  getCampaignStatus: (campaignId: string) => boolean;
}
